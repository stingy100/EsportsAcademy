# eSports Academy - ASP.NET Core MVC

Plataforma de inscripción de jugadores para torneos universitarios de eSports.

## Ejecutar
```bash
dotnet run
```
Abrir la URL que indique la consola (ej. https://localhost:5001).

## Estructura
- `Models/` entidad `Jugador` con validaciones (DataAnnotations)
- `Services/` lógica de almacenamiento en memoria
- `Controllers/` `HomeController`, `JugadoresController` (GET/POST)
- `Views/` vistas Razor (.cshtml) con Bootstrap 5
- `wwwroot/` CSS y JS estáticos
